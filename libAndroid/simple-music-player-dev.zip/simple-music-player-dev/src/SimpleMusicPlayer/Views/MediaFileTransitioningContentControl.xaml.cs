﻿using System;
using MahApps.Metro.Controls;

namespace SimpleMusicPlayer.Views
{
    public partial class MediaFileTransitioningContentControl : TransitioningContentControl
    {
        public MediaFileTransitioningContentControl()
        {
            InitializeComponent();
        }
    }
}
