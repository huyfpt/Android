﻿using MahApps.Metro.Native;

namespace SimpleMusicPlayer.Core.Interfaces
{
    public interface IWindowPlacementSetting
    {
        WINDOWPLACEMENT? Placement { get; set; }
    }
}