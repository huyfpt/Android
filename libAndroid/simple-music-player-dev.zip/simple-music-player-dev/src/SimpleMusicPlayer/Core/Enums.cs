﻿namespace SimpleMusicPlayer.Core
{
    public enum PlayerState
    {
        Stop,
        Play,
        Pause
    }
}